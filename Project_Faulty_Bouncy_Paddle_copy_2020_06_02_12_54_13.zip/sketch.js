var ball,paddle,ballImage,paddleImage,topEdge,bottomEdge,leftEdge;

function preload() {
  ballImage=loadImage("ball.png");
  paddleImage=loadImage("paddle.png");
}

function setup() {
  createCanvas(400, 400);
   ball=createSprite(20,200,20,20);
  ball.addImage(ballImage);
  ball.velocityX=9
  paddle=createSprite(300,200,10,70);
  paddle.addImage(paddleImage);
  edges = createEdgeSprites();
}
function draw() {
  background(205,153,0);
  ball.bounceOff(edges[3]);
  ball.bounceOff(edges[0]);
  ball.bounceOff(edges[2]);
  ball.bounceOff(paddle);
  if(keyDown("up"))
  {
   paddle.y=paddle.y-20;
  }
  
  if(keyDown("down"))
  {
    
   paddle.y=paddle.y+20;
  }
   drawSprites();
}
  
  
 


function randomVelocity()
{
  
  
}